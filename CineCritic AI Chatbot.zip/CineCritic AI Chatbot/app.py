from flask import Flask, render_template, request, jsonify
import os
import google.generativeai as genai
from dotenv import load_dotenv

app = Flask(__name__)

# Load API key from .env file
load_dotenv()
api_key = os.getenv("GOOGLE_API_KEY")
if not api_key:
    # Print a helpful error but allow the application to start for demonstration
    # In production, this should be a ValueError that stops the app.
    print("WARNING: GOOGLE_API_KEY not found. API calls will fail.")
    api_key = "" 

# Configure the Gemini client
try:
    genai.configure(api_key=api_key)
except Exception as e:
    print(f"Error configuring Generative AI client: {e}")

# Role for the chatbot
ROLE = "Movie Review Expert"

# Define the system instruction globally
SYSTEM_INSTRUCTION = (
    f"You are an expert in the role of: '{ROLE}'. "
    f"Respond to user queries about movies by providing structured and concise reviews. "
    f"Each review must include the following clearly labeled sections:\n"
    f"Overall Sentiment: (Positive / Negative / Mixed)\n"
    f"Reasoning: (One line explanation of the sentiment)\n"
    f"Highlights:\n"
    f"- [List 1 to 2 points that were strong in the movie]\n"
    f"Lowlights:\n"
    f"- [List 1 to 2 points that were weak in the movie]\n"
    f"Suggestions:\n"
    f"- [Recommend alternative movies if needed]\n"
    f"Keep the tone informative and objective. Do not use Markdown symbols like *, **, or headings(###). "
    f"Do not write in paragraph format. Use line-by-line structure as shown. "
    f"If a query is out of scope, respond ONLY with the phrase: 'This prompt is outside the scope of the assigned role: {ROLE}.'"
)

# Load Gemini model, passing the system instruction here
# Model initialization will now correctly apply the instruction to the model.
MODEL_NAME = "gemini-2.5-pro"
try:
    model = genai.GenerativeModel(
        model_name=MODEL_NAME,
        system_instruction=SYSTEM_INSTRUCTION # <-- FIX: Passed system instruction here!
    )
except Exception as e:
    print(f"Error initializing model {MODEL_NAME}: {e}")

# Chat session and initialization flag
chat_session = None
initialized = False

@app.route("/")
def index():
    """Renders the main application page."""
    return render_template("index.html")

@app.route("/chat", methods=["POST"])
def chat():
    """Handles the user's movie review request via the chat session."""
    global chat_session, initialized
    data = request.get_json()
    movie_name = data.get("movie_name", "").strip()

    if not movie_name:
        return jsonify({"reply": "Please provide a movie name."})

    try:
        # Initialize chat session if not already
        if not initialized:
            # FIX: We no longer pass the system instruction here
            chat_session = model.start_chat()
            initialized = True
            
        # Generate movie review based on the movie name
        user_prompt = f"Please provide a review for the movie: {movie_name}"

        # Send the prompt to the model and get the response
        response = chat_session.send_message(user_prompt)

        # Check for out-of-scope response
        if "outside the scope" in response.text:
             return jsonify({"reply": response.text})
        else:
            return jsonify({"reply": response.text})

    except Exception as e:
        # This catches API errors and other exceptions
        return jsonify({"reply": f"An API Error Occurred: {e.__class__.__name__}: {str(e)}"})

if __name__ == "__main__":
    print(f"Starting Flask App. Using model: {MODEL_NAME}")
    app.run(debug=True)